from .api import ShotcutAPI
from .exceptions import ShotcutAPIError

__version__ = "1.0.0"
__all__ = ["ShotcutAPI", "ShotcutAPIError"]
