class ShortcutAPIError(Exception):
    """Base exception for Shotcut API errors"""
    pass

class AuthenticationError(ShortcutAPIError):
    """Raised when authentication fails"""
    pass

class RateLimitError(ShortcutAPIError):
    """Raised when rate limit is exceeded"""
    pass
