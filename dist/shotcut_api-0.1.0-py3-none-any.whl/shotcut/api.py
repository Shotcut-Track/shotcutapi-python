import requests
from datetime import datetime
from typing import Optional, Dict, List, Union
from .exceptions import ShortcutAPIError, AuthenticationError, RateLimitError
from .models import Link, Campaign, Channel

class ShortcutAPI:
    """
    Python client for the Shotcut.in API
    """
    BASE_URL = "https://shotcut.in/api"

    def __init__(self, api_key: str):
        """
        Initialize the API client
        
        Args:
            api_key (str): Your Shotcut API key
        """
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })

    def _handle_response(self, response: requests.Response) -> Dict:
        """Handle API response and errors"""
        if response.status_code == 429:
            raise RateLimitError("Rate limit exceeded")
        elif response.status_code == 401:
            raise AuthenticationError("Invalid API key")
        elif response.status_code >= 400:
            raise ShortcutAPIError(f"API request failed: {response.text}")
        
        data = response.json()
        if data.get("error") and data["error"] != "0":
            raise ShortcutAPIError(data.get("message", "Unknown error"))
        
        return data

    def create_link(self, url: str, **kwargs) -> Link:
        """
        Create a shortened URL
        
        Args:
            url (str): The URL to shorten
            **kwargs: Optional parameters (custom, password, expiry, etc.)
        
        Returns:
            Link: The created link object
        """
        data = {"url": url, **kwargs}
        response = self.session.post(f"{self.BASE_URL}/url/add", json=data)
        result = self._handle_response(response)
        
        return Link(
            id=result["id"],
            alias=result["shorturl"].split("/")[-1],
            shorturl=result["shorturl"],
            longurl=url,
            clicks=0
        )

    def get_link(self, link_id: int) -> Link:
        """
        Get details for a single link
        
        Args:
            link_id (int): The ID of the link
            
        Returns:
            Link: The link object
        """
        response = self.session.get(f"{self.BASE_URL}/url/{link_id}")
        result = self._handle_response(response)
        
        details = result["details"]
        return Link(
            id=result["id"],
            alias=details["shorturl"].split("/")[-1],
            shorturl=details["shorturl"],
            longurl=details["longurl"],
            clicks=result["data"]["clicks"],
            title=details.get("title"),
            description=details.get("description"),
            date=datetime.fromisoformat(details["date"]) if details.get("date") else None
        )

    def get_links(self, limit: int = 100, page: int = 1, order: str = "date") -> List[Link]:
        """
        Get list of links
        
        Args:
            limit (int): Number of results per page
            page (int): Page number
            order (str): Sort order ('date' or 'click')
            
        Returns:
            List[Link]: List of link objects
        """
        params = {"limit": limit, "page": page, "order": order}
        response = self.session.get(f"{self.BASE_URL}/urls", params=params)
        result = self._handle_response(response)
        
        return [Link(**url) for url in result["data"]["urls"]]

    def create_campaign(self, name: str, **kwargs) -> Campaign:
        """
        Create a new campaign
        
        Args:
            name (str): Campaign name
            **kwargs: Optional parameters
            
        Returns:
            Campaign: The created campaign object
        """
        data = {"name": name, **kwargs}
        response = self.session.post(f"{self.BASE_URL}/campaign/add", json=data)
        result = self._handle_response(response)
        
        return Campaign(
            id=result["id"],
            name=result["domain"],
            public=result["public"],
            rotator=result.get("rotator"),
            list=result.get("list")
        )