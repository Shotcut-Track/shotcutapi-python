# Shotcut API Python Client

A Python client library for the Shotcut.in URL shortening API.

## Installation

```bash
pip install shotcut-api
```

## Quick Start

```python
from shotcut import ShortcutAPI

# Initialize the client
api = ShortcutAPI("your_api_key")

# Create a shortened URL
link = api.create_link(
    url="https://example.com",
    custom="mylink"  # Optional custom alias
)
print(f"Shortened URL: {link.shorturl}")
```

## Features

- Create and manage shortened URLs
- Handle campaigns and channels
- Custom domain support
- Full API coverage
- Type hints for better IDE support
- Proper error handling

## Documentation

For full documentation, visit [our documentation page](https://github.com/yourusername/shotcut-api).

## License

This project is licensed under the MIT License - see the LICENSE file for details.