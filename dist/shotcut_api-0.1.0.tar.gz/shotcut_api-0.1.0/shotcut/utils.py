from typing import Optional
from datetime import datetime, timezone

def format_datetime(dt: Optional[datetime]) -> Optional[str]:
    """Format datetime for API requests"""
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()
