from dataclasses import dataclass
from typing import Optional, List, Dict
from datetime import datetime

@dataclass
class Link:
    id: int
    alias: str
    shorturl: str
    longurl: str
    clicks: int
    title: Optional[str] = None
    description: Optional[str] = None
    date: Optional[datetime] = None

@dataclass
class Campaign:
    id: int
    name: str
    public: bool
    rotator: Optional[str] = None
    list: Optional[str] = None

@dataclass
class Channel:
    id: int
    name: str
    description: Optional[str] = None
    color: Optional[str] = None
    starred: bool = False
